package com.priya.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PriyaAIApp() } } }

@Composable fun PriyaAIApp() {
    var selected by remember { mutableIntStateOf(0) }
    MaterialTheme { Scaffold(bottomBar={ NavigationBar {
        listOf("💕 Chat","🎙️ Voice","🖼️ Images","📋 Assistant","⚙️ Settings").forEachIndexed { i,label ->
            NavigationBarItem(selected=i==selected,onClick={selected=i},icon={Text(label.take(2),fontSize=18.sp)},label={Text(label.drop(2).trim())})
        }
    }}) { pad -> when(selected) {
        0 -> ChatScreen(Modifier.padding(pad)); 1 -> VoiceScreen(Modifier.padding(pad));
        2 -> SimpleScreen("🖼️ AI Images","Create and edit images with Priya.",Modifier.padding(pad));
        3 -> SimpleScreen("📋 Personal Assistant","Notes, reminders and daily planning.",Modifier.padding(pad));
        else -> SimpleScreen("⚙️ Settings","Personality, language, privacy and memory.",Modifier.padding(pad))
    } } }
}

@Composable fun ChatScreen(mod: Modifier) {
    var text by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Priya: হ্যালো ❤️ আমি তোমার সঙ্গে কথা বলার জন্য প্রস্তুত।")) }
    Column(mod.fillMaxSize().padding(16.dp)) {
        Text("Priya AI",fontSize=28.sp,fontWeight=FontWeight.Bold); Text("তোমার personal AI companion",color=Color.Gray); Spacer(Modifier.height(16.dp))
        Column(Modifier.weight(1f)) { messages.forEach { m -> Surface(shape=RoundedCornerShape(18.dp),tonalElevation=2.dp,modifier=Modifier.padding(vertical=5.dp)){ Text(m,Modifier.padding(14.dp),fontSize=16.sp) } } }
        Row(verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(text,{text=it},Modifier.weight(1f),placeholder={Text("কিছু বলো…")}); Spacer(Modifier.width(8.dp)); Button(onClick={if(text.isNotBlank()){messages=messages+"তুমি: $text"+"Priya: শুনছি ❤️";text=""}},shape=CircleShape){Text("➤")} }
    }
}
@Composable fun VoiceScreen(mod:Modifier){Column(mod.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("🎙️",fontSize=64.sp);Text("Priya Voice",fontSize=28.sp,fontWeight=FontWeight.Bold);Text("Voice chat interface — AI voice service can be connected next.");Spacer(Modifier.height(24.dp));Button(onClick={}){Text("🎙️ Talk to Priya")}}}
@Composable fun SimpleScreen(title:String,body:String,mod:Modifier){Column(mod.fillMaxSize().padding(24.dp)){Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Text(body,fontSize=17.sp);Spacer(Modifier.height(24.dp));Button(onClick={}){Text("Coming next")}}}
